package com.ianatul.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView rvMobil;
    private ArrayList<Mobil> list = new ArrayList<>();
    ImageView ivTopbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvMobil = findViewById(R.id.rv_host);
        rvMobil.setHasFixedSize(true);

        ivTopbar = findViewById(R.id.iv_topbar_main);
        ivTopbar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent move = new Intent(MainActivity.this, About.class);
                startActivity(move);
            }
        });

        list.addAll(MobilData.getListData());
        showRecyclerList();
    }

    private void showRecyclerList(){
        rvMobil.setLayoutManager(new LinearLayoutManager(this));
        MobilAdapter mobilAdapter = new MobilAdapter(list);
        rvMobil.setAdapter(mobilAdapter);

        mobilAdapter.setOnItemClickCallback(new MobilAdapter.OnItemClickCallback() {
            @Override
            public void onItemClicked(Mobil data) {
                intentSelect(data);
            }
        });
    }

    private void intentSelect(Mobil host) {
        Intent move = new Intent(MainActivity.this, Deskripsi.class);
        move.putExtra("photo", host.getPhoto());
        move.putExtra("nama", host.getNama());
        move.putExtra("deskripsi", host.getDeskripsi());
        startActivity(move);
    }
}
