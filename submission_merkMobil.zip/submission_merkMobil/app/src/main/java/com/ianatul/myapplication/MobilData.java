package com.ianatul.myapplication;

import java.util.ArrayList;

public class MobilData {
    private static String[] mobilNames = {
            "Mitsubishi",
            "Honda",
            "Suzuki",
            "Toyota",
            "Daihatsu",
            "Nissan",
            "BMW",
            "Isuzu",
            "Jaguar",
            "Datsun"
    };
    private static String[] mobilDeskripsi = {
            "Mitsubishi sebuah perusahaan Jepang yang menaungi berbagai perusahaan yang berbagi merek dagang dan bagian perusahaan Mitsubishi. Perusahaan ini didirikan pada tahun 1870 sebagai perusahaan pelayaran oleh Yataro Iwasaki.",
            "Honda Honda didirikan pada 24 September 1948 oleh Soichiro Honda. Honda merupakan produsen sepeda motor terbesar di dunia sejak 1959,dan juga produsen mesin pembakaran dalam terbesar dengan produksi lebih dari 14 juta unit tiap tahun.",
            "Suzuki Suzuki merupakan salah satu raksasa otomotif dunia. Nama pabrikan ini pun berasal dari nama belakang sang pendiri, Michio Suzuki pada 1909 sebagai Suzuki Loom Works. Lahir sebagai anak dari petani kapas tradisional Jepang, Suzuki pun menciptakan alat tenun kayu saat usianya 22 tahun.Suzuki merupakan salah satu raksasa otomotif dunia. Nama pabrikan ini pun berasal dari nama belakang sang pendiri, Michio Suzuki pada 1909 sebagai Suzuki Loom Works. Lahir sebagai anak dari petani kapas tradisional Jepang, Suzuki pun menciptakan alat tenun kayu saat usianya 22 tahun.",
            "Toyota sebuah pabrikan mobil yang berasal dari Jepang, yang berpusat di Toyota, Aichi. Saat ini, Toyota merupakan pabrikan penghasil mobil terbesar di dunia.\n" +
                    "\n" +
                    "Di samping memproduksi mobil, Toyota juga memberikan pelayanan finansial, dan juga membuat robot. TMC merupakan anggota dari Grup Toyota dan memproduksi mobil dengan merek Toyota, Lexus dan Scion, Daihatsu dan Hino, dan memiliki sebagian kecil saham Subaru dan Isuzu. ",
            "Daihatsu Sebagai ATPM, ADM merupakan satu-satunya perusahaan yang berhak mengimpor, merakit dan membuat kendaraan bermerk Daihatsu di Indonesia. ADM merupakan perusahaan joint venture antara Daihatsu Motor Company dengan Astra International yang ada sejak tahun 1978.\n" +
                    "\n" +
                    "Kendaraan bermerk Daihatsu yang di jual di Indonesia dan dipasarkan oleh Astra adalah Daihatsu Zebra, Ceria, Charade, Taft, Feroza, Taruna, Xenia, Terios, Sirion, Gran Max, Luxio, Ayla dan Sigra.\n" +
                    "\n" +
                    "Kendaraan Daihatsu sepenuhnya didistribusikan oleh Astra melalui Divisi Daihatsu Sales Operation yang memiliki 137 jaringan penjualan di seluruh Indonesia, di mana 71 outlet penjualan merupakan cabang langsung dari Astra. " +
                    "Setiap layanan Web Hosting tentunya memiliki keunggulan yang berbeda-beda. Begitu juga dengan Rumahweb. Mereka memiliki komitmen untuk bisa menjaga kepercayaan pelanggan agar tetap menggunakan layanannya. Prinsip seperti itulah yang diterapkan oleh Rumahweb sehingga sampai saat ini masih menjadi penyedia layanan Web Hosting yang menyediakan harga yang murah dan berkualitas",
            "Nissan  Nissan merupakan salah satu perusahaan manufaktur otomotif terbaik di dunia. Sejarah besar Nissan dimulai saat pendiriannya oleh Kwaishinsa pada 1911. Di awal pendiriannya perusahaan ini dikenal dengan nama Kwaishinsa Motor Car Works.\n" +
                    "\n" +
                    "Hingga akhirnya pada tahun 1913, Kwaishinsa berhasil membuat mobil pertamanya dan diberi nama model DAT. Menurut catatan sejarah Nissan, DAT juga merupakan cikal bakal kemunculan perusahaan Datsun sebagai produsen mobil di samping truk sebagai produksi utama mereka.\n" +
                    "\n" +
                    "Nama Kwaishinsa sendiri mulai diubah menjadi Nissan pada tahun 1934. Perubahan ini dilakukan karena Yoshisuke Aikawa sebagai pemilik perusahaan induk Nihon Sangyo yang membeli lini produksi mobil kecil DAT Motor. Nah, Nihon Sangyo merupakan kepanjang dari Nissan." +
                    "Niagahoster juga menyediakan web Hosting untuk website wordpress yang sudah dilengkapi dengan fitur paling aman sehingga Anda akan tak perlu khawatir saat menggunakan website di mana saja dan kapan saja. Mereka juga menjanjikan berbagai kemudahan untuk Anda yang memilih menggunakan layanannya.",
            "BMW (singkatan untuk Bayerische Motoren Werke, atau dalam Bahasa Inggris, Bavarian Motor Works), adalah sebuah perusahaan otomotif Jerman yang memproduksi mobil dan sepeda motor. BMW didirikan pada tahun 1916 oleh Franz Josef Popp. BMW AG adalah perusahaan induk dari merk mobil MINI dan Rolls-Royce, dan, dulunya Rover. BMW dikenal sebagai salah satu perusahaan mobil mewah dengan performa tinggi, dan juga salah satu perusahaan mobil pertama yang menggunakan teknologi ABS. " +
                    "Masterweb adalah salah satu penyedia layanan hosting dan domain yang sudah dikenal banyak orang, khususnya yang telah lama bermain di dunia Web Hosting. Layanan ini sudah berdiri sejak 15 tahun dan semakin berkembang hingga sekarang.",
            "Isuzu merupakan sebuah perusahaan otomotif Jepang yang memproduksi berbagai macam kendaraan bermesin diesel. Isuzu kebanyakan memproduksi kendaraan komersial dan truk berat. Perusahaan ini berpusat di Tokyo, didirikan pada tahun 1937. Tahun 2005, Isuzu menjadi produsen truk medium dan truk besar yang terbesar di dunia. Perusahaan ini mempunyai pabrik di Fujisawa, prefektur Tochigi dan Hokkaido. " +
                    "Sejak awal berdiri sampai sekarang, DomaiNesia telah memiliki lebih dari 45.000 pelanggan yang tak hanya berasal dari Indonesia saja saja tetapi juga Mancanegara. Hal ini tentu saja membuat banyak orang bertanya-tanya, meski banyak saingan mengapa DomaiNesia masih saja menjadi pilihan Web Hosting terbaik meskipun banyak sekali saingannya.",
            "Jaguar adalah sebuah produsen mobil Britania. Didirikan pada 1922 sebagai Swallow Sidecar Company oleh William Lyons, perusahaan ini dinamakan Jaguar Cars setelah PDII karena konotasi jelek dari inisial SS. Perusahaan ini sejak Maret 2008 dimiliki oleh Tata Motors (sebelumnya dari tahun 1990 hingga 2008 Jaguar dimiliki Ford Motor Company). Jaguar dikenal dengan mobil saloon mewah dan olahraga, segmentasi pasar yang telah dimilikinya sejak 1930-an. " +
                    "Berdasarkan pengalaman kami, Hostinger sangat direkomendasikan untuk Anda yang ingin mewujudkan keberhasilan dalam berbisnis online dengan web hosting tercepat dan aman. Hostinger juga menawarkan harga dengan diskon hingga 90% per bulan. Tentu ini menjadi poin penting bagi seseorang yang akan memutuskan untuk membeli web hosting.",
            "Datsunadalah merek mobil yang dimiliki oleh Nissan Motor Company. Datsun digunakan sebagai merek dari kendaraan Nissan yang diekspor tahun 1958 sampai 1986. Pada tahun 2013, Datsun diluncurkan kembali sebagai merek mobil murah Nissan.\n" +
                    "\n" +
                    "Nama ini dibuat pada tahun 1931 oleh DAT Motorcar Co. untuk model baru mobil mereka dengan nama Datson. " +
                    "Semua pelanggan tentunya ingin memiliki website dengan keunggulan yang berkualitas serta memiliki akses yang lebih optimal. Untuk masalah tersebut Anda tak perlu khawatir karena Unlimited.id hadir dengan layanan yang akan membantu Anda dalam menghadirkan tingkat kepuasan yang tinggi."
    };
    private static int[] hostingImage = {
            R.drawable.mitsubishi,
            R.drawable.honda,
            R.drawable.suzuki,
            R.drawable.toyota,
            R.drawable.daihatsu,
            R.drawable.nissan,
            R.drawable.bmw,
            R.drawable.isuzu,
            R.drawable.jaguar,
            R.drawable.datsun
    };
    public static ArrayList<Mobil> getListData(){
        ArrayList<Mobil> list = new ArrayList<>();

        for(int i=0;i<mobilNames.length;i++){
            Mobil host = new Mobil();
            host.setNama(mobilNames[i]);
            host.setDeskripsi(mobilDeskripsi[i]);
            host.setPhoto(hostingImage[i]);
            list.add(host);
        }
        return list;
    }
}


